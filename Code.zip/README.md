# Projet TP Git

**Nom du projet : À REMPLACER PAR LE GROUPE**

Bienvenue dans ce petit TP Git.

Vous modifierez plusieurs fichiers simples via différents tickets.
